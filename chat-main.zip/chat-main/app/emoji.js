import EmojiSelector from 'react-native-emoji-selector';

const sendEmojiReaction = (emoji) => {
  // Enviar a reação para o Firestore
  addDoc(collection(db, 'reactions'), {
    emoji,
    messageId: message.id,
    timestamp: new Date(),
  });
};

return <EmojiSelector onEmojiSelected={sendEmojiReaction} />;

// exibir nas mensagens 
const Reactions = ({ reactions }) => (
    <View>
      {reactions.map((reaction, index) => (
        <Text key={index}>{reaction.emoji}</Text>
      ))}
    </View>
  );
  