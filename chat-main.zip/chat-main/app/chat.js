//exibir img no chat:
import { Image } from 'react-native';

const Message = ({ message }) => (
  <View>
    {message.imageUrl ? (
      <Image
        source={{ uri: message.imageUrl }}
        style={{ width: 200, height: 200 }}
      />
    ) : (
      <Text>{message.text}</Text>
    )}
  </View>
);
