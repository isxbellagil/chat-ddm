import * as ImagePicker from 'expo-image-picker';

const pickImage = async () => {
  let result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsEditing: true,
    aspect: [4, 3],
    quality: 1,
  });

  if (!result.cancelled) {
    uploadImageToFirebase(result.uri);
  }
};

const takePicture = async () => {
  let result = await ImagePicker.launchCameraAsync({
    allowsEditing: true,
    aspect: [4, 3],
    quality: 1,
  });

  if (!result.cancelled) {
    uploadImageToFirebase(result.uri);
  }
};
//upload
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const uploadImageToFirebase = async (uri) => {
  const blob = await fetch(uri).then((response) => response.blob());
  const storage = getStorage();
  const imageRef = ref(storage, `images/${Date.now()}`);

  uploadBytes(imageRef, blob).then((snapshot) => {
    getDownloadURL(snapshot.ref).then((downloadURL) => {
      saveImageURLToFirestore(downloadURL);
    });
  });
};
//salvar
import { getFirestore, collection, addDoc } from 'firebase/firestore';

const saveImageURLToFirestore = async (url) => {
  const db = getFirestore();
  try {
    await addDoc(collection(db, 'messages'), {
      imageUrl: url,
      timestamp: new Date(),
    });
  } catch (e) {
    console.error('Error adding document: ', e);
  }
};
//verifica se img foi enviada
import * as Permissions from 'expo-permissions';

const getPermissions = async () => {
  const { status } = await Permissions.askAsync(Permissions.MEDIA_LIBRARY, Permissions.CAMERA);
  if (status !== 'granted') {
    alert('A permissão de acesso à câmera/galeria é necessária.');
  }
};
