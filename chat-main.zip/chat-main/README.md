#React Native Chat

## Início

instale dependências dev

### `npm install`

## Inicie a configuração do Firebase

- Crie um novo projeto no console do Firebase
- Crie um aplicativo da web do Firebase e copie as configurações para o arquivo firebaseConfig.js no diretório raiz

## Depois

Execute o aplicativo

### `npm start`

Execute no modo de desenvolvimento.

Abra-o no [aplicativo Expo](https://expo.io) no seu telefone para visualizá-lo. Ele será recarregado se você salvar as edições em seus arquivos, e você verá erros de compilação e logs no terminal.

#### `npm run ios`

#### `npm run android`
