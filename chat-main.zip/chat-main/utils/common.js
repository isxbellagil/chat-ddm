// String que representa um "blurred" (borrado) da imagem, usado para exibir enquanto a imagem real carrega
export const blurhash = '|rF?hV%2WCj[ayj[a|j[az_NaeWBj@ayfRayfQfQM{M|azj[azf6fQfQfQIpWXofj[ayj[j[fQayWCoeoeaya}j[ayfQa{oLj?j[WVj[ayayj[fQoff7azayj[ayj[j[ayofayayayj[fQj[ayayj[ayfjj[j[ayjuayj[';

// Função que gera um ID único de sala de chat entre dois usuários
export const getRoomId = (userId1, userId2) => {
    // Ordena os IDs para garantir que a ordem não afete o resultado (para que 'user1-user2' seja igual a 'user2-user1')
    const sortedIds = [userId1, userId2].sort(); 
    
    // Cria o ID da sala juntando os dois IDs com um hífen
    const roomId = sortedIds.join('-'); 
    
    // Retorna o ID da sala gerado
    return roomId;
}

// Função que formata uma data para o formato 'dia mês' (exemplo: 10 Dec)
export const formatDate = (date) => {
    // Obtém o dia do mês
    var day = date.getDate(); 
    
    // Array com os nomes dos meses
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    
    // Obtém o nome do mês a partir do índice do mês
    var month = monthNames[date.getMonth()]; 
    
    // Formata a data no formato 'dia mês'
    var formattedDate = day + ' ' + month; 
    
    // Retorna a data formatada
    return formattedDate;
}
