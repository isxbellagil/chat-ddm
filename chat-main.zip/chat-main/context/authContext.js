// Importando hooks e funções necessárias
import { createContext, useContext, useEffect, useState } from "react"; 
import { onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth'; 
import { auth, db } from "../firebaseConfig"; // Importando a configuração do Firebase
import { doc, getDoc, setDoc } from 'firebase/firestore'; // Funções do Firestore para manipulação de documentos

// Criando o contexto de autenticação
export const AuthContext = createContext();

// Provedor do contexto de autenticação
export const AuthContextProvider = ({children}) => {
    // Estados para gerenciar o usuário e o estado de autenticação
    const [user, setUser] = useState(null); 
    const [isAuthenticated, setIsAuthenticated] = useState(undefined);

    // useEffect é usado para verificar o estado de autenticação do usuário
    useEffect(() => {
        const unsub = onAuthStateChanged(auth, (user) => {
            // Verifica se o usuário está autenticado
            if (user) {
                setIsAuthenticated(true); // Usuário autenticado
                setUser(user); // Define o usuário autenticado
                updateUserData(user.uid); // Atualiza os dados do usuário no Firestore
            } else {
                setIsAuthenticated(false); // Usuário não autenticado
                setUser(null); // Limpa os dados do usuário
            }
        });
        return unsub; // Retorna a função de limpeza para o useEffect
    }, []);

    // Função para atualizar os dados do usuário no Firestore
    const updateUserData = async (userId) => {
        const docRef = doc(db, 'users', userId); // Referência ao documento do usuário
        const docSnap = await getDoc(docRef); // Pega o documento do Firestore

        if (docSnap.exists()) {
            // Se o documento existir, atualiza o estado com os dados
            let data = docSnap.data();
            setUser({
                ...user, 
                username: data.username, 
                profileUrl: data.profileUrl, 
                userId: data.userId
            });
        }
    }

    // Função para login do usuário
    const login = async (email, password) => {
        try {
            // Tenta fazer o login com o Firebase Authentication
            const response = await signInWithEmailAndPassword(auth, email, password);
            return { success: true }; // Retorna sucesso
        } catch (e) {
            // Captura erros e retorna mensagens personalizadas
            let msg = e.message;
            if (msg.includes('(auth/invalid-email)')) msg = 'E-mail inválido';
            if (msg.includes('(auth/invalid-credential)')) msg = 'E-mail ou Senha errada';
            return { success: false, msg }; // Retorna erro com mensagem
        }
    }

    // Função para logout do usuário
    const logout = async () => {
        try {
            // Faz o logout com o Firebase Authentication
            await signOut(auth);
            return { success: true }; // Retorna sucesso
        } catch (e) {
            return { success: false, msg: e.message, error: e }; // Retorna erro com mensagem
        }
    }

    // Função para registrar um novo usuário
    const register = async (email, password, username, profileUrl) => {
        try {
            // Cria o novo usuário com o Firebase Authentication
            const response = await createUserWithEmailAndPassword(auth, email, password);
            console.log('response.user :', response?.user); // Exibe no console os dados do usuário

            // Armazena os dados do novo usuário no Firestore
            await setDoc(doc(db, "users", response?.user?.uid), {
                username,
                profileUrl,
                userId: response?.user?.uid
            });
            return { success: true, data: response?.user }; // Retorna sucesso com os dados do usuário
        } catch (e) {
            // Captura erros e retorna mensagens personalizadas
            let msg = e.message;
            if (msg.includes('(auth/invalid-email)')) msg = 'E-mail inválido';
            if (msg.includes('(auth/email-already-in-use)')) msg = 'Esse e-mail já está em uso';
            return { success: false, msg }; // Retorna erro com mensagem
        }
    }

    // Retorna o contexto com as variáveis e funções de autenticação
    return (
        <AuthContext.Provider value={{ user, isAuthenticated, login, register, logout }}>
            {children} {/* Renderiza os filhos (componentes dentro do AuthContextProvider) */}
        </AuthContext.Provider>
    );
}

// Custom hook para usar o contexto de autenticação
export const useAuth = () => {
    const value = useContext(AuthContext); // Pega o valor do contexto

    // Lança erro se o hook for usado fora do contexto
    if (!value) {
        throw new Error('useAuth must be wrapped inside AuthContextProvider');
    }
    return value; // Retorna o valor do contexto
}
